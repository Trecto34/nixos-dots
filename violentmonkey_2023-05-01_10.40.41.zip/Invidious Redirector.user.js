// ==UserScript==
// @name         Invidious Redirector
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Redirect YouTube to Invidious
// @author       Your Name
// @match        https://www.youtube.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const invidiousURL = "vid.priv.au";

    if (window.location.href.indexOf('watch?v=') > -1) {
        let newURL = window.location.href.replace("www.youtube.com/watch?v=", invidiousURL + "/watch?v=");
        if (newURL.indexOf('&') > -1) {
            newURL = newURL.substring(0, newURL.indexOf('&'));
        }
        window.location.replace(newURL);
    }

})();
