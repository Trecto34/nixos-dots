// ==UserScript==
// @name         Block Social Media
// @version      1.1
// @description  Block social media sites from 07:00 to 18:00
// @author       Trecto
// @match        *://*.facebook.com/*
// @match        *://*.twitter.com/*
// @match        *://*.instagram.com/*
// @match        *://*.linkedin.com/*
// @match        *://*.pinterest.com/*
// @match        *://*.reddit.com/*
// @match        *://*.tumblr.com/*
// @match        *://*.snapchat.com/*
// @match        *://*.youtube.com/*
// @grant        none
// ==/UserScript==

const date = new Date();
const hours = date.getHours();

const style = document.createElement('style');
style.innerHTML = `
.pauseButton {
  background-color: #6200EE;
  color: white;
  font-family: 'Roboto', sans-serif;
  font-weight: 500;
  font-size: 14px;
  padding: 8px 16px;
  text-transform: uppercase;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  outline: none;
  position: relative;
  overflow: hidden;
  transition: background-color 0.3s;
}

.pauseButton:hover {
  background-color: #3700B3;
}

.pauseButton:focus {
  box-shadow: 0 0 0 4px rgba(98, 0, 238, 0.5);
}

.pauseButton:active {
  background-color: #270086;
}
`;
document.head.appendChild(style);

function unblock() {
    document.getElementById('blocker').style.display = 'none';
    setTimeout(() => {
        block();
    }, 15 * 60 * 1000); // Unblock for 15 minutes
}

function block() {
    const blocker = document.createElement('div');
    blocker.id = 'blocker';
    blocker.style.position = 'absolute';
    blocker.style.top = '0';
    blocker.style.left = '0';
    blocker.style.width = '100%';
    blocker.style.height = '100%';
    blocker.style.backgroundColor = 'black';
    blocker.style.zIndex = '9999';

    const message = document.createElement('div');
    message.style.position = 'absolute';
    message.style.top = '50%';
    message.style.left = '50%';
    message.style.transform = 'translate(-50%, -50%)';
    message.style.fontSize = '48px';
    message.style.fontWeight = 'bold';
    message.style.color = 'white';
    message.style.textAlign = 'center';
    message.innerHTML = 'BACK TO WORK<br>';

    const button = document.createElement('button');
    button.innerHTML = "I'm in pause";
    button.className = 'pauseButton';
    button.addEventListener('click', unblock);

    message.appendChild(button);
    blocker.appendChild(message);
    document.body.appendChild(blocker);
}

if (hours >= 7 && hours < 18) {
    block();
}
